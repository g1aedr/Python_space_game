from fastapi import FastAPI, Query
from core.globals import sim

app = FastAPI()

# === SENSOR: Get Ship Status ===
@app.get("/sensor/status")
def get_status():
    return {
        "position": [sim.ship.x, sim.ship.y],
        "angle": sim.ship.angle,
        "velocity": [sim.ship.vx, sim.ship.vy],
        "health": sim.ship.health
    }

# === ACTUATORS ===

@app.post("/actuator/thrust")
def thrust():
    sim.ship.move_forward()
    return {"message": "Thrust applied"}

@app.post("/actuator/rotate")
def rotate(direction: str = Query(..., pattern="^(left|right)$")):
    if direction == "left":
        sim.ship.rotate(1)
    elif direction == "right":
        sim.ship.rotate(-1)
    return {"message": f"Rotated {direction}"}

@app.post("/actuator/fire")
def fire():
    sim.fire_bullet()
    return {"message": "Bullet fired"}
