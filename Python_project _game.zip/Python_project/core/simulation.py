from objects.ship import Ship
from objects.enemy import Enemy

class Simulation:
    def __init__(self, map_width=9600, map_height=7200):
        self.map_width = map_width
        self.map_height = map_height
        self.ship = Ship(map_width // 2, map_height // 2)
        self.ship.health = 100
        self.bullets = []
        self.walls = []
        self.circles = []
        self.enemies = [
            Enemy(500, 500),
            Enemy(800, 1200)
        ]

    def step(self):
        self.ship.update_position(self.walls, self.circles, self.map_width, self.map_height)

        for enemy in self.enemies:
            enemy.update_position(self.walls, self.circles, self.map_width, self.map_height)
            bullet = enemy.ai(self.ship)
            if bullet:
                self.bullets.append(bullet)

        for bullet in self.bullets:
            bullet.update(self.walls + self.circles)

            if bullet.owner == "enemy":
                dist = ((bullet.x - self.ship.x)**2 + (bullet.y - self.ship.y)**2)**0.5
                if dist < self.ship.size:
                    self.ship.health -= 10
                    bullet.active = False

            elif bullet.owner == "player":
                for enemy in self.enemies:
                    dist = ((bullet.x - enemy.x)**2 + (bullet.y - enemy.y)**2)**0.5
                    if dist < enemy.size:
                        enemy.health -= 20  # Player deals damage
                        bullet.active = False
                        break

        self.bullets = [b for b in self.bullets if b.active]

    def fire_bullet(self):
        from objects.bullet import Bullet
        bullet = Bullet(self.ship.x, self.ship.y, self.ship.angle, owner="player")
        self.bullets.append(bullet)
