import math
import random
from objects.ship import Ship
from objects.bullet import Bullet
import pygame

class Enemy(Ship):
    def __init__(self, x, y, color=(255, 200, 0)):
        super().__init__(x, y)
        self.color = color
        self.health = 100# Weaker enemies
        self.fire_cooldown = 0

    def ai(self, player):
        dx = player.x - self.x
        dy = player.y - self.y
        self.angle = math.degrees(math.atan2(-dy, dx))  # y is flipped

        if random.random() < 0.4:
            self.move_forward()

        if self.fire_cooldown <= 0 and random.random() < 0.02:
            self.fire_cooldown = 30
            return Bullet(self.x, self.y, self.angle, owner="enemy")
        else:
            self.fire_cooldown -= 1
        return None

    def draw(self, surface, offset):
        radians = math.radians(self.angle)
        tip = (self.x + self.size * math.cos(radians), self.y - self.size * math.sin(radians))
        left = (self.x + self.size * math.cos(radians + 2.5), self.y - self.size * math.sin(radians + 2.5))
        right = (self.x + self.size * math.cos(radians - 2.5), self.y - self.size * math.sin(radians - 2.5))
        points = [tip, left, right]
        shifted = [(p[0] - offset[0], p[1] - offset[1]) for p in points]
        pygame.draw.polygon(surface, self.color, shifted)
