import requests
import random
import time

API_URL = "http://127.0.0.1:8000"

def rotate():
    direction = random.choice(["left", "right"])
    try:
        requests.post(f"{API_URL}/actuator/rotate", params={"direction": direction})
        print(f"Rotated {direction}")
    except:
        pass

def thrust():
    try:
        requests.post(f"{API_URL}/actuator/thrust")
        print("Thrust applied")
    except:
        pass

def fire():
    try:
        requests.post(f"{API_URL}/actuator/fire")
        print("Bullet fired")
    except:
        pass

def get_status():
    try:
        res = requests.get(f"{API_URL}/sensor/status")
        return res.json()
    except:
        return {}

def run_dummy():
    while True:
        rotate()
        if random.random() < 0.7:
            thrust()
        if random.random() < 0.2:
            fire()

        status = get_status()
        print(f"Status: {status}")

        time.sleep(0.1)  # 100 ms per loop

if __name__ == "__main__":
    run_dummy()
