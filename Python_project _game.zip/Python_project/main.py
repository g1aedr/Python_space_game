import threading
import uvicorn
from visualizer import viewer  # viewer.run() is your game loop

# Function to run FastAPI server in background
def run_api():
    uvicorn.run("api.server:app", host="127.0.0.1", port=8000, reload=False)

# Entry point for the program
if __name__ == "__main__":
    threading.Thread(target=run_api, daemon=True).start()  # Run API in background
    viewer.run()  # Run the game
