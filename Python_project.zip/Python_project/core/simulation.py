import random
import math
from objects.ship import Ship
from objects.enemy import Enemy
import core.globals as g


class Simulation:
    def __init__(self, map_width=9600, map_height=7200):
        self.map_width = map_width
        self.map_height = map_height
        self.ship = Ship(map_width // 2, map_height // 2)
        self.ship.health = 100
        self.bullets = []
        self.walls = []
        self.circles = []
        self.enemies = []

        # Generazione iniziale dei nemici
        while len(self.enemies) < 4:
            self.respawn_enemy()

    def respawn_enemy(self):
        min_distance = 200
        max_tries = 100

        for _ in range(max_tries):
            x = random.randint(0, self.map_width)
            y = random.randint(0, self.map_height)

            # Verifica che sia lontano dagli altri nemici
            too_close = False
            for enemy in self.enemies:
                if math.hypot(enemy.x - x, enemy.y - y) < min_distance:
                    too_close = True
                    break

            # Verifica che sia lontano dal giocatore
            if math.hypot(self.ship.x - x, self.ship.y - y) < min_distance:
                too_close = True

            if not too_close:
                self.enemies.append(Enemy(x, y))
                break

    def step(self):
        self.ship.update_position(self.walls, self.circles, self.map_width, self.map_height)

        for enemy in self.enemies:
            enemy.update_position(self.walls, self.circles, self.map_width, self.map_height)
            bullet = enemy.ai(self.ship)
            if bullet:
                self.bullets.append(bullet)

        for bullet in self.bullets:
            bullet.update(self.walls + self.circles)

            if bullet.owner == "enemy":
                dist = ((bullet.x - self.ship.x)**2 + (bullet.y - self.ship.y)**2)**0.5
                if dist < self.ship.size:
                    self.ship.health -= 10
                    bullet.active = False

            elif bullet.owner == "player":
                for enemy in self.enemies:
                    dist = ((bullet.x - enemy.x)**2 + (bullet.y - enemy.y)**2)**0.5
                    if dist < enemy.size:
                        enemy.health -= 20
                        bullet.active = False
                        if enemy.health <= 0:
                            g.score += 50  # <-- incremento il punteggio
                        break

        self.bullets = [b for b in self.bullets if b.active]
        self.enemies = [e for e in self.enemies if e.health > 0]

        # Respawn nemici mancanti
        while len(self.enemies) < 3:
            self.respawn_enemy()

    def fire_bullet(self):
        from objects.bullet import Bullet
        bullet = Bullet(self.ship.x, self.ship.y, self.ship.angle, owner="player")
        self.bullets.append(bullet)
