import pygame
from visualizer.viewer_config import WIDTH, HEIGHT, BLACK, WHITE, RED

def show_game_over_screen(screen, font, final_score, nickname, background):
    screen.blit(background, (0, 0))

    try:
        with open("scores.txt", "a") as f:
            f.write(f"{nickname}:{final_score}\n")
    except:
        pass

    scores = []
    try:
        with open("scores.txt", "r") as f:
            lines = f.readlines()
        for line in lines:
            name, score = line.strip().split(":")
            scores.append((name, int(score)))
    except:
        pass

    top_scores = sorted(scores, key=lambda x: x[1], reverse=True)[:5]

    game_over_text = font.render("GAME OVER", True, RED)
    score_text = font.render(f"Your Score: {final_score}", True, WHITE)
    screen.blit(game_over_text, ((WIDTH - game_over_text.get_width()) // 2, 80))
    screen.blit(score_text, ((WIDTH - score_text.get_width()) // 2, 130))

    y = 180
    for i, (name, score) in enumerate(top_scores, 1):
        line = font.render(f"{i}. {name} - {score}", True, WHITE)
        screen.blit(line, ((WIDTH - line.get_width()) // 2, y))
        y += 30

    prompt = font.render("Click to return to main menu", True, WHITE)
    screen.blit(prompt, ((WIDTH - prompt.get_width()) // 2, y + 20))
    pygame.display.flip()

    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                waiting = False
