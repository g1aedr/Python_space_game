# viewer_config.py

WIDTH, HEIGHT = 800, 600

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED   = (255, 0, 0)
GRAY  = (100, 100, 100)
YELLOW = (255, 255, 0)
