import pygame
from visualizer.viewer_config import WIDTH, HEIGHT, BLACK, WHITE, GREEN

def show_start_screen(screen, font, background):
    nickname = ""
    input_active = True

    input_box = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2, 200, 32)
    start_button = pygame.Rect(WIDTH // 2 - 60, HEIGHT // 2 + 60, 120, 40)

    while True:
        screen.blit(background, (0, 0))
        title_text = font.render("Ship Game", True, WHITE)
        screen.blit(title_text, ((WIDTH - title_text.get_width()) // 2, 100))

        instructions = [
            "Kill the enemies before they kill you",
            "COMMANDS:",
            "W - thrust   S - brake",
            "D - clockwise    A - counterclockwise",
            "SPACE - shoot"
        ]
        for i, line in enumerate(instructions):
            line_surf = font.render(line, True, WHITE)
            screen.blit(line_surf, ((WIDTH - line_surf.get_width()) // 2, 160 + i * 25))

        pygame.draw.rect(screen, WHITE, input_box, 2)
        text_surf = font.render(nickname, True, WHITE)
        screen.blit(text_surf, (input_box.x + 5, input_box.y + 5))

        pygame.draw.rect(screen, GREEN, start_button)
        btn_text = font.render("Start", True, BLACK)
        screen.blit(btn_text, (start_button.x + 25, start_button.y + 8))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            elif event.type == pygame.KEYDOWN and input_active:
                if event.key == pygame.K_RETURN:
                    input_active = False
                elif event.key == pygame.K_BACKSPACE:
                    nickname = nickname[:-1]
                elif len(nickname) < 15:
                    nickname += event.unicode
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if start_button.collidepoint(event.pos) and nickname.strip():
                    return nickname.strip()
