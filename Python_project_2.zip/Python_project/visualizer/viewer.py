import pygame
import random
from core.globals import sim

# === DISPLAY CONFIG ===
WIDTH, HEIGHT = 800, 600
MAP_WIDTH, MAP_HEIGHT = sim.map_width, sim.map_height
FPS = 60

# === COLORS ===
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
GRAY = (100, 100, 100)
YELLOW = (255, 255, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)

# === OBSTACLE CLASSES ===

class CircleObstacle:
    def __init__(self, x, y, radius):
        self.x = x
        self.y = y
        self.radius = radius

    def draw(self, surface, offset):
        pygame.draw.circle(surface, GRAY, (int(self.x - offset[0]), int(self.y - offset[1])), self.radius)

class Wall:
    def __init__(self, x, y, width, height):
        self.rect = pygame.Rect(x, y, width, height)

    def draw(self, surface, offset):
        shifted = self.rect.move(-offset[0], -offset[1])
        pygame.draw.rect(surface, GRAY, shifted)

# === RADAR ===

def draw_radar(surface, ship, walls, circles):
    radar_width = WIDTH // 6
    radar_height = HEIGHT // 6
    radar_x = WIDTH - radar_width - 10
    radar_y = HEIGHT - radar_height - 10
    radar_rect = pygame.Rect(radar_x, radar_y, radar_width, radar_height)

    pygame.draw.rect(surface, (30, 30, 30), radar_rect)
    pygame.draw.rect(surface, WHITE, radar_rect, 2)

    view_width = WIDTH * 2
    view_height = HEIGHT * 2
    view_left = ship.x - view_width // 2
    view_top = ship.y - view_height // 2

    def map_to_radar(x, y):
        rel_x = x - view_left
        rel_y = y - view_top
        rx = radar_x + (rel_x / view_width) * radar_width
        ry = radar_y + (rel_y / view_height) * radar_height
        return int(rx), int(ry)

    def in_range(x, y):
        return (view_left <= x <= view_left + view_width and
                view_top <= y <= view_top + view_height)

    for wall in sim.walls:
        x, y = wall.rect.centerx, wall.rect.centery
        if in_range(x, y):
            rx, ry = map_to_radar(x, y)
            pygame.draw.rect(surface, GRAY, pygame.Rect(rx - 2, ry - 2, 4, 4))

    for circle in sim.circles:
        if in_range(circle.x, circle.y):
            rx, ry = map_to_radar(circle.x, circle.y)
            pygame.draw.circle(surface, GRAY, (rx, ry), 3)

    rx, ry = map_to_radar(ship.x, ship.y)
    pygame.draw.circle(surface, YELLOW, (rx, ry), 4)

    for enemy in sim.enemies:
        if in_range(enemy.x, enemy.y):
            rx, ry = map_to_radar(enemy.x, enemy.y)
            pygame.draw.circle(surface, RED, (rx, ry), 4)

# === OBSTACLE GENERATOR ===

def generate_obstacles(count):
    walls = []
    circles = []
    for _ in range(count):
        if random.random() < 0.5:
            w = random.randint(20, 60)
            h = random.randint(20, 60)
            x = random.randint(0, MAP_WIDTH - w)
            y = random.randint(0, MAP_HEIGHT - h)
            walls.append(Wall(x, y, w, h))
        else:
            r = random.randint(15, 50)
            x = random.randint(r, MAP_WIDTH - r)
            y = random.randint(r, MAP_HEIGHT - r)
            circles.append(CircleObstacle(x, y, r))
    return walls, circles

# === DRAW ENEMY HP BAR ===

def draw_enemy_hp_bar(surface, enemy, offset):
    bar_width = 30
    bar_height = 5
    hp_pct = max(enemy.health, 0) / 100

    x = int(enemy.x - offset[0] - bar_width / 2)
    y = int(enemy.y - offset[1] - 25)

    if hp_pct > 0.6:
        color = GREEN
    elif hp_pct > 0.3:
        color = YELLOW
    else:
        color = RED

    pygame.draw.rect(surface, WHITE, (x - 1, y - 1, bar_width + 2, bar_height + 2), 1)
    pygame.draw.rect(surface, color, (x, y, int(bar_width * hp_pct), bar_height))

# === MAIN LOOP ===

def run():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Ship Game - With Enemy")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont(None, 32)

    sim.walls, sim.circles = generate_obstacles(100)

    running = True
    while running:
        clock.tick(FPS)

        keys = pygame.key.get_pressed()
        if keys[pygame.K_a]:
            sim.ship.rotate(1)
        if keys[pygame.K_d]:
            sim.ship.rotate(-1)
        if keys[pygame.K_w]:
            sim.ship.move_forward()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    sim.fire_bullet()

        sim.step()
        offset = (sim.ship.x - WIDTH // 2, sim.ship.y - HEIGHT // 2)

        if sim.ship.health <= 0:
            from random import randint
            sim.ship.x = randint(100, MAP_WIDTH - 100)
            sim.ship.y = randint(100, MAP_HEIGHT - 100)
            sim.ship.vx = 0
            sim.ship.vy = 0
            sim.ship.health = 100
            print("Player respawned!")

        sim.enemies = [e for e in sim.enemies if e.health > 0]

        screen.fill(BLACK)
        sim.ship.draw(screen, offset)

        for wall in sim.walls:
            wall.draw(screen, offset)
        for circle in sim.circles:
            circle.draw(screen, offset)
        for bullet in sim.bullets:
            bullet.draw(screen, offset)
        for enemy in sim.enemies:
            enemy.draw(screen, offset)
            draw_enemy_hp_bar(screen, enemy, offset)

        draw_radar(screen, sim.ship, sim.walls, sim.circles)

        pygame.draw.rect(screen, RED, pygame.Rect(-offset[0], -offset[1], MAP_WIDTH, MAP_HEIGHT), 5)

        # === Player HP bar ===
        bar_x = 10
        bar_y = HEIGHT - 24
        bar_width = 100
        bar_height = 12
        hp_pct = max(sim.ship.health, 0) / 100

        if hp_pct > 0.6:
            hp_color = GREEN
        elif hp_pct > 0.3:
            hp_color = YELLOW
        else:
            hp_color = RED

        pygame.draw.rect(screen, WHITE, (bar_x - 2, bar_y - 2, bar_width + 4, bar_height + 4), 1)
        pygame.draw.rect(screen, hp_color, (bar_x, bar_y, bar_width * hp_pct, bar_height))

        # === Sorted Scoreboard (numbers only, color-coded) ===
        scores = [(sim.score, sim.ship.color)] + [(e.score, e.color) for e in sim.enemies]
        scores.sort(reverse=True, key=lambda s: s[0])
        for i, (score_val, color) in enumerate(scores):
            score_text = font.render(str(score_val), True, color)
            screen.blit(score_text, (WIDTH - score_text.get_width() - 10, 10 + i * 30))

        pygame.display.flip()

    pygame.quit()
