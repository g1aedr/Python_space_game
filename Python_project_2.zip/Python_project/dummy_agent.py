import requests
import time
import math

API = "http://127.0.0.1:8000"

def post(endpoint, **kwargs):
    try:
        requests.post(f"{API}{endpoint}", **kwargs)
    except:
        pass

def get_world():
    try:
        return requests.get(f"{API}/sensor/world").json()
    except:
        return None

def rotate(direction):
    post("/actuator/rotate", params={"direction": direction})

def thrust():
    post("/actuator/thrust")

def fire():
    post("/actuator/fire")

def distance(a, b):
    return math.hypot(a["x"] - b["x"], a["y"] - b["y"])

def angle_to(a, b):
    dx, dy = b["x"] - a["x"], b["y"] - a["y"]
    return math.degrees(math.atan2(-dy, dx)) % 360

def angle_diff(a1, a2):
    return abs((a1 - a2 + 180) % 360 - 180)

def is_clear(ship, angle, walls, circles, map_w, map_h):
    test_x = ship["x"] + 40 * math.cos(math.radians(angle))
    test_y = ship["y"] - 40 * math.sin(math.radians(angle))

    # Check map bounds
    if not (0 < test_x < map_w and 0 < test_y < map_h):
        return False

    # Check wall collisions
    for wall in walls:
        if wall["x"] <= test_x <= wall["x"] + wall["w"] and wall["y"] <= test_y <= wall["y"] + wall["h"]:
            return False

    # Check circle collisions
    for c in circles:
        if math.hypot(test_x - c["x"], test_y - c["y"]) < c["r"] + 10:
            return False

    return True

def run_smart_dummy():
    while True:
        world = get_world()
        if not world:
            time.sleep(0.2)
            continue

        ship = world["ship"]
        enemies = [e for e in world["enemies"] if e["health"] > 0]
        walls = world["walls"]
        circles = world["circles"]
        map_w, map_h = world["map"]["width"], world["map"]["height"]

        if not enemies:
            time.sleep(0.1)
            continue

        # === Find closest enemy ===
        target = min(enemies, key=lambda e: distance(ship, e))
        target_angle = angle_to(ship, target)
        diff = angle_diff(ship["angle"], target_angle)

        # === Rotate if needed ===
        if diff > 5:
            rotate("left" if (target_angle - ship["angle"]) % 360 < 180 else "right")

        # === Fire if aligned and in range ===
        if diff < 10 and distance(ship, target) < 350:
            fire()

        # === Thrust only if path is clear ===
        if is_clear(ship, ship["angle"], walls, circles, map_w, map_h):
            thrust()

        time.sleep(0.1)

if __name__ == "__main__":
    run_smart_dummy()
