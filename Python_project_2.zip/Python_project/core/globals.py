from core.simulation import Simulation
sim = Simulation()
