import random
from objects.ship import Ship
from objects.enemy import Enemy

class Simulation:
    def __init__(self, map_width=9600, map_height=7200):
        self.map_width = map_width
        self.map_height = map_height

        # Define 10 distinct colors
        self.available_colors = [
            (0, 255, 0), (0, 0, 255), (255, 0, 255), (0, 255, 255),
            (255, 255, 0), (255, 165, 0), (255, 0, 0),
            (128, 128, 0), (128, 0, 128), (0, 128, 128)
        ]
        random.shuffle(self.available_colors)

        self.ship = Ship(map_width // 2, map_height // 2, color=self.available_colors.pop())
        self.ship.health = 100
        self.bullets = []
        self.walls = []
        self.circles = []

        self.enemies = [
            Enemy(500, 500, color=self.available_colors.pop()),
            Enemy(800, 1200, color=self.available_colors.pop())
        ]

        self.score = 0  # Player's score

    def respawn_enemy(self, dead_enemy):
        """Respawn enemy with same color and score"""
        new_enemy = Enemy(
            x=random.randint(100, self.map_width - 100),
            y=random.randint(100, self.map_height - 100),
            color=dead_enemy.color
        )
        new_enemy.score = dead_enemy.score  # Keep score
        return new_enemy

    def step(self):
        self.ship.update_position(self.walls, self.circles, self.map_width, self.map_height)

        for enemy in self.enemies:
            enemy.update_position(self.walls, self.circles, self.map_width, self.map_height)
            bullet = enemy.ai(self.ship, self.enemies)

            if bullet:
                self.bullets.append(bullet)

        for bullet in self.bullets:
            bullet.update(self.walls + self.circles)

            if bullet.owner == "enemy":
                dist = ((bullet.x - self.ship.x) ** 2 + (bullet.y - self.ship.y) ** 2) ** 0.5
                if dist < self.ship.size:
                    self.ship.health -= 10
                    bullet.active = False
                    for e in self.enemies:
                        if e.color == bullet.color:
                            e.score += 10
                            if self.ship.health <= 0:
                                e.score += 50
                            break

            elif bullet.owner == "player":
                for i, enemy in enumerate(self.enemies):
                    dist = ((bullet.x - enemy.x) ** 2 + (bullet.y - enemy.y) ** 2) ** 0.5
                    if dist < enemy.size:
                        enemy.health -= 20
                        self.score += 10
                        bullet.active = False
                        if enemy.health <= 0:
                            self.score += 50
                            # Respawn enemy with same color/score
                            self.enemies[i] = self.respawn_enemy(enemy)
                        break

        self.bullets = [b for b in self.bullets if b.active]

        # Respawn player if dead
        if self.ship.health <= 0:
            self.ship.x = random.randint(100, self.map_width - 100)
            self.ship.y = random.randint(100, self.map_height - 100)
            self.ship.vx = 0
            self.ship.vy = 0
            self.ship.health = 100
            self.score = max(0, self.score - 100)  # Lose score on death
            print("Player respawned! -100 score")

    def fire_bullet(self):  # ✅ Fixed fire_bullet method
        from objects.bullet import Bullet
        bullet = Bullet(
            self.ship.x,
            self.ship.y,
            self.ship.angle,
            owner="player",
            color=self.ship.color
        )
        self.bullets.append(bullet)
