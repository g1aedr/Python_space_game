import math
import random
from objects.ship import Ship
from objects.bullet import Bullet
import pygame

class Enemy(Ship):
    def __init__(self, x, y, color):
        super().__init__(x, y, color)
        self.health = 100
        self.fire_cooldown = 0
        self.score = 0

    def ai(self, player, enemies):
        # === Build target list: player + other enemies (excluding self) ===
        potential_targets = [player] + [e for e in enemies if e is not self and e.health > 0]

        if not potential_targets:
            return None

        # === Choose a target based on lowest health, then nearest ===
        target = min(
            potential_targets,
            key=lambda t: (t.health, math.hypot(t.x - self.x, t.y - self.y))
        )

        # === Rotate toward target ===
        dx = target.x - self.x
        dy = target.y - self.y
        self.angle = math.degrees(math.atan2(-dy, dx))  # y is flipped

        # === Move forward randomly ===
        if random.random() < 0.4:
            self.move_forward()

        # === Fire occasionally ===
        if self.fire_cooldown <= 0 and random.random() < 0.02:
            self.fire_cooldown = 30
            return Bullet(self.x, self.y, self.angle, owner="enemy", color=self.color)
        else:
            self.fire_cooldown -= 1

        return None

    def draw(self, surface, offset):
        radians = math.radians(self.angle)
        tip = (self.x + self.size * math.cos(radians), self.y - self.size * math.sin(radians))
        left = (self.x + self.size * math.cos(radians + 2.5), self.y - self.size * math.sin(radians + 2.5))
        right = (self.x + self.size * math.cos(radians - 2.5), self.y - self.size * math.sin(radians - 2.5))
        points = [tip, left, right]
        shifted = [(p[0] - offset[0], p[1] - offset[1]) for p in points]
        pygame.draw.polygon(surface, self.color, shifted)
