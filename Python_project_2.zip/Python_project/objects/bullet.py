import math
import pygame

class Bullet:
    def __init__(self, x, y, angle, owner, color, speed=8):
        self.x = x
        self.y = y
        self.angle = angle
        self.owner = owner
        self.speed = speed
        self.active = True
        self.color = color  # NEW

    def update(self, obstacles):
        if not self.active:
            return
        self.x += self.speed * math.cos(math.radians(self.angle))
        self.y -= self.speed * math.sin(math.radians(self.angle))
        bullet_rect = pygame.Rect(self.x - 2, self.y - 2, 4, 4)

        for obs in obstacles:
            if hasattr(obs, 'rect') and bullet_rect.colliderect(obs.rect):
                self.active = False
                break
            elif hasattr(obs, 'x') and hasattr(obs, 'y') and hasattr(obs, 'radius'):
                distance = math.hypot(self.x - obs.x, self.y - obs.y)
                if distance < obs.radius:
                    self.active = False
                    break

        if not (0 <= self.x <= 9600 and 0 <= self.y <= 7200):
            self.active = False

    def draw(self, surface, offset):
        if self.active:
            pygame.draw.circle(
                surface,
                self.color,
                (int(self.x - offset[0]), int(self.y - offset[1])),
                4
            )
